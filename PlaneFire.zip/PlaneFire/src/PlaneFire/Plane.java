package PlaneFire;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Plane extends JPanel{
	final static int HEIGHT=700;
	final static int WIDTH=400;
	static final int START=0;
	static final int PAUSE=1;
	static final int END=2;
	static final int RUNNING=3;
	static int NOW=START;
	public static BufferedImage airplaneImage;
	public static BufferedImage beeImage;
	public static BufferedImage heroImage;
	public static BufferedImage startImage;
	public static BufferedImage endImage;
	public static BufferedImage pauseImage;
	public static BufferedImage bossImage;
	public static BufferedImage bulletImage;
	public static BufferedImage background;
	private FlyObject enemyplane[]={};
	private Bullet bullet[]={};
	private static Hero hero=new Hero();
	private static Sky sky=new Sky(0,0,0,0);
	private Bee bee[]={};
	private static BossPlane boss;
	
	static{
		try{
			airplaneImage=ImageIO.read(Plane.class.getResource("airplane.png"));
			beeImage=ImageIO.read(Plane.class.getResource("bee1.png"));
			heroImage=ImageIO.read(Plane.class.getResource("hero1.png"));
			startImage=ImageIO.read(Plane.class.getResource("start.png"));
			endImage=ImageIO.read(Plane.class.getResource("end.png"));
			pauseImage=ImageIO.read(Plane.class.getResource("pause.png"));
			bossImage=ImageIO.read(Plane.class.getResource("boss.png"));
			bulletImage=ImageIO.read(Plane.class.getResource("bullet.gif"));
			background=ImageIO.read(Plane.class.getResource("background3.jpg"));
		System.out.println("���سɹ�");
		}catch(Exception e){
			System.out.println("����1");
			e.printStackTrace();//������
		}
	}
	
	public void action(){
		MouseAdapter ma=new MouseAdapter(){
			public void mouseMoved(MouseEvent e){
				if(NOW==RUNNING){
					hero.x=e.getX()-heroImage.getWidth()/2;
					hero.y=e.getY()-heroImage.getHeight()/2;
				}
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				switch(NOW){
				case START:
					NOW=RUNNING;
					hero.setLife(6);
					break;
				case RUNNING:
					NOW=PAUSE;
					break;
				case END:
					NOW=START;
					break;
				case PAUSE:
					NOW=RUNNING;
					break;
				}
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseEntered(e);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseExited(e);
			}
			
			
		};
		this.addMouseListener(ma);       //������
		this.addMouseMotionListener(ma); //����ƶ�
		Timer timer = new Timer();
		int inters = 10;
		timer.schedule(new TimerTask() {
			
			//���еķ���
			@Override
			public void run() {
				// TODO Auto-generated method stub
				if(NOW==RUNNING){
					ProduceEnemyAirplane();
					ProduceBullets();
					ProduceBoss();
					OutBoundArray();
					MovePlane();
					Collision();
					IsGameOver();
				}
				repaint();
			}
		}, inters, inters);// �ƻ�����
	}
	
	protected void ProduceBoss() {
		boss=new BossPlane((WIDTH-bossImage.getWidth())/2,0,bossImage.getWidth(),bossImage.getHeight());
	}

	protected void IsGameOver() {
		if(hero.isDead()){
			NOW=END;
		}
	}

	protected void Collision() {
		// TODO Auto-generated method stub
		int index=0;
		for(int i=0;i<bullet.length;i++){
			for(int j=0;j<enemyplane.length;j++){
//				System.out.println(bullet[i].isHit(enemyplane[j]));
//				System.out.println(enemyplane[j].isHit(bullet[i]));
//				System.out.println(i+"bullet:"+bullet[i].x+":"+bullet[i].y+":"+bullet[i].x1+":"+bullet[i].y1);
//				System.out.println(j+"enemyplane:"+enemyplane[j].x+":"+enemyplane[j].y+":"+enemyplane[j].x1+":"+enemyplane[j].y1);
				if(enemyplane[j].isHit(bullet[i])&&enemyplane[j].islive()&&bullet[i].islive()){
					bullet[i].Hit();
					enemyplane[j].Hit();
					hero.score+=1;
				}
			}
			
		}
		Bullet[] flyBullet=new Bullet[bullet.length];
		index=0;
		for(int i=0;i<bullet.length;i++){
			//System.out.println(i+"bullet:"+bullet[i].life);
			if(bullet[i].islive()){
				flyBullet[index]=bullet[i];
				index++;
			}
		}
		//�ӵ���ײbee
		bullet=Arrays.copyOf(flyBullet, index);
		for(int i=0;i<bee.length;i++){
			for(int j=0;j<bullet.length;j++){
				if(bee[i].isHit(bullet[j])&&bee[i].islive()&&bullet[j].islive()){
					bee[i].Hit();
					bullet[j].Hit();
					Random rand=new Random();
					int x=rand.nextInt(20);
					if(x<=7) hero.DoubleFire+=30;
					else hero.score+=10;
				}
			}
		}
		Bee[] flyBee=new Bee[bee.length];
		index=0;
		for(int i=0;i<bee.length;i++){
			if(bee[i].islive()){
				flyBee[index]=bee[i];
				index++;
			}
		}
		bee=Arrays.copyOf(flyBee, index);
		//�л���ײӢ�ۻ�
		for(int i=0;i<enemyplane.length;i++){
			if(hero.isHit(enemyplane[i])&&enemyplane[i].islive()){
				hero.life--;
				enemyplane[i].Hit();
			}
		}
		FlyObject[] flyenemy=new FlyObject[enemyplane.length];
		index=0;
		for(int i=0;i<enemyplane.length;i++){
			//System.out.println(i+"enemyplane:"+enemyplane[i].life);
			if(enemyplane[i].islive()){
				flyenemy[index]=enemyplane[i];
				index++;
			}
		}
		enemyplane=Arrays.copyOf(flyenemy, index);
	}

	protected void MovePlane() {
		for(int i=0;i<enemyplane.length;i++)
		{
			enemyplane[i].move();
		}
		for(int i=0;i<bullet.length;i++)
		{
			bullet[i].move();
		}
		for(int i=0;i<bee.length;i++)
			bee[i].move();
		boss.move();
	}

	protected void OutBoundArray() {//ɾ��Խ�缰��������
		// TODO Auto-generated method stub
		FlyObject[] flyenemy=new FlyObject[enemyplane.length];
		int index=0;
		for(int i=0;i<enemyplane.length;i++){
			if(!enemyplane[i].isOutbound()){
				flyenemy[index]=enemyplane[i];
				index++;
			}
		}
		enemyplane=Arrays.copyOf(flyenemy, index);
		Bullet[] flyBullet=new Bullet[bullet.length];
		index=0;
		for(int i=0;i<bullet.length;i++){
			if(!bullet[i].isOutbound()){
				flyBullet[index]=bullet[i];
				index++;
			}
		}
//		System.out.println(bullet.length+" x 1");
//		System.out.println(enemyplane.length+" x 2");
		bullet=Arrays.copyOf(flyBullet, index);
	}
	
	int enterBullet=0;
	protected void ProduceBullets() {//�����ӵ�
		enterBullet++;
		if(enterBullet%20==0){
			Bullet bt=new Bullet(hero.x+heroImage.getWidth()/2, hero.y,bulletImage.getWidth(),bulletImage.getHeight());
			Bullet []b;
			if(hero.DoubleFire>0){
				b=new Bullet[2];
				b[0]=new Bullet(hero.x, hero.y,bulletImage.getWidth(),bulletImage.getHeight());
				b[1]=new Bullet(hero.x+heroImage.getWidth(), hero.y,bulletImage.getWidth(),bulletImage.getHeight());
				hero.DoubleFire-=2;
			}else{
				b=new Bullet[1];
				b[0]=new Bullet(hero.x+heroImage.getWidth()/2, hero.y,bulletImage.getWidth(),bulletImage.getHeight());
			}
			
			
			bullet = Arrays.copyOf(bullet, bullet.length + b.length);
			// ���������ӵ�����ŵ�Դ�����е����һ��Ԫ��
			System.arraycopy(b, 0, bullet, bullet.length - b.length,b.length);
//			bullet=Arrays.copyOf(bullet, bullet.length+1);
//			bullet[bullet.length-1]=bt;
		}
	}
    int enterIndex=0;
	protected void ProduceEnemyAirplane() {
		enterIndex++;
		if(enterIndex%20==0){
			Airplane ap=new Airplane(airplaneImage.getHeight(),airplaneImage.getWidth());
			enemyplane=Arrays.copyOf(enemyplane, enemyplane.length+1);
			enemyplane[enemyplane.length-1]=ap;
		}else if(enterIndex%200==0){
			Bee b=new Bee(beeImage.getHeight(), beeImage.getWidth());
			bee=Arrays.copyOf(bee, bee.length+1);
			bee[bee.length-1]=b;
		}
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		//�����
				sky.paintObject(g);
		//���л�
		for(int i=0;i<enemyplane.length;i++){
			enemyplane[i].paintObject(g);
		}
		//��bee
		for(int i=0;i<bee.length;i++){
			bee[i].paintObject(g);
		}
		//���ӵ�
		for(int i=0;i<bullet.length;i++)
		{
			bullet[i].paintObject(g);
		}
		//��Ӣ�ۻ�
		hero.paintObject(g);
		//boss
		if(hero.score>100){
			boss.paintObject(g);
		}
		
		//����
		g.drawString("������" + hero.score, 30, 160);
		g.drawString("������" + hero.getLife(), 30,180);
		switch(NOW){
		case START: g.drawImage(startImage, 0, 0,null);break;
		case PAUSE : break;
		case RUNNING:break;
		case END:    g.drawImage(endImage, 0, 0,null);break;
		}
	}

	public static void main(String[] args) {
		JFrame frame=new JFrame();
		Plane plane=new Plane();
		frame.add(plane);
		frame.setSize(WIDTH,HEIGHT);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		plane.action();
		
	}
}

package PlaneFire;

import java.awt.image.BufferedImage;

public class Bee extends FlyObject{
	//��̬�����
	Bee(int height, int width) {
		super(height, width);
		this.life=1;
	}
	@Override
	public BufferedImage getImage() {
		return Plane.beeImage;
	}
	@Override
	public void move() {
		this.y+=2;
		this.y1+=2;
	}

}

package PlaneFire;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Airplane extends FlyObject{
	
	Airplane(int height, int width) {
		super(height, width);
		life=1;//����
	}

	private static BufferedImage images;
	//��̬�����

	@Override
	public BufferedImage getImage() {
		// TODO Auto-generated method stub
		return Plane.airplaneImage;
	}
	public void paintObject(Graphics g) {
		g.drawImage(this.getImage(), this.x, this.y, null);
	}
	@Override
	public void move() {
		this.y+=2;
		this.y1+=2;
	}

}

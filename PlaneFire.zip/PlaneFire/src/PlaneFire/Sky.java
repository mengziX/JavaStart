package PlaneFire;

import java.awt.image.BufferedImage;

public class Sky extends FlyObject{



	Sky(int x, int y, int width, int height) {
		super(x, y, width, height);
		// TODO Auto-generated constructor stub
	}

	@Override
	public BufferedImage getImage() {
		// TODO Auto-generated method stub
		return Plane.background;
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		
	}

}

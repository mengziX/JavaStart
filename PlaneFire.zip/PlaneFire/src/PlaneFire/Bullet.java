package PlaneFire;

import java.awt.image.BufferedImage;

public class Bullet extends FlyObject{

	private static BufferedImage images;
	//��̬�����
	Bullet(int x, int y, int width, int height) {
		super(x, y, width, height);
		life=1;//����
	}

	public boolean isOutbound(){
		if(y<0) return true;
		else return false;
	}
	@Override
	public BufferedImage getImage() {
		// TODO Auto-generated method stub
		return Plane.bulletImage;
	}
	public void move() {
		this.y-=10;
		this.y1-=10;
	}

}

package PlaneFire;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

import javax.imageio.ImageIO;

public abstract class FlyObject {
	protected int x,x1;
	protected int y,y1;
	protected int life;
	protected int width;
	protected int height;
	protected int xspeed;
	FlyObject(int height,int width){                 //�л����۷�
		Random rand=new Random();
		this.height=height;
		this.width=width;
		this.x=rand.nextInt(Plane.WIDTH- this.width);//x����ֵ
		this.y=-height;                              //y����ֵ
		this.x1=this.x+width;
		this.y1=this.y+height;
	}
	FlyObject(int x,int y,int width,int height){
		this.x=x;
		this.y=y;
		this.height=height;
		this.width=width;
		this.x1=x+width;
		this.y1=y+height;
	}
	public void paintObject(Graphics g) {
		g.drawImage(this.getImage(), this.x, this.y, null);
	}
	public int getXspeed() {
		return xspeed;
	}
	public void setXspeed(int xspeed) {
		this.xspeed = xspeed;
	}
	public int getYspeed() {
		return yspeed;
	}
	public void setYspeed(int yspeed) {
		this.yspeed = yspeed;
	}
	protected int yspeed;
	public static  BufferedImage  loadImage(String filename){
		return Plane.airplaneImage;
	}
	public abstract BufferedImage getImage();
	public boolean isDie(){
		if(life==0) return true;
		else return false;
	}
	public boolean isOutbound(){
		if(y>Plane.HEIGHT) return true;
		else return false;
	}
	public int getX1() {
		return x1;
	}
	public void setX1(int x1) {
		this.x1 = x1;
	}
	public int getY1() {
		return y1;
	}
	public void setY1(int y1) {
		this.y1 = y1;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getLife() {
		return life;
	}
	public void setLife(int life) {
		this.life = life;
	}
	/**
	 * x,y  x1,y
	 * 
	 * x,y1 x1,y1
	 * n,m
	 * n>x n<x1 m> m<y1
	 * @param fly
	 * @return
	 */
	public boolean isHit(FlyObject fly){
		int n,m;
		//�ĸ���
		//fly.x; fly.y;
		//fly.x; fly.y1;
		//fly.x1 fly.y
		n=fly.x;
		m=fly.y;
		if(n>x&&n<x1&&m>y&&m<y1){
			return true;
		}
		n=fly.x1;
		m=fly.y;
		if(n>x&&n<x1&&m>y&&m<y1){
			return true;
		}
		n=fly.x;
		m=fly.y1;
		if(n>x&&n<x1&&m>y&&m<y1){
			return true;
		}
		n=fly.x1;
		m=fly.y1;
		if(n>x&&n<x1&&m>y&&m<y1){
			return true;
		}
		return false;
		
	}
	public void Hit(){
		life--;
	}
	public boolean islive(){
		if(life>0) return true;
		return false;
	}
	public boolean isDead() {
		if(life<=0) return true;
		return false;
	}
	public abstract void move() ;
	
}

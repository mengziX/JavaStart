package PlaneFire;

import java.awt.image.BufferedImage;

public class BossPlane extends FlyObject{
	

	BossPlane(int x, int y, int width, int height) {
		super(x, y, width, height);
		// TODO Auto-generated constructor stub
	}

	@Override
	public BufferedImage getImage() {
		return Plane.bossImage;
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		this.y+=2;
		this.y1+=2;
	}
}

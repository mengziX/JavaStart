package PlaneFire;

import java.awt.image.BufferedImage;

public class Hero extends FlyObject{

	int score;
	int DoubleFire;
	public Hero(){
		super(97, 124, 140, 400);
		life = 6;
		DoubleFire = 20;//��������
		score=0;
	}

	void add(int life){
		this.life=life;
	}
	Bullet[] shootBullet(){
		return null;	
	}
	@Override
	public BufferedImage getImage() {
		return Plane.heroImage;
	}
	public Bullet[] shoot(){
		Bullet[] b=new Bullet[2];
		return null;
	}
	@Override
	public void move() {
		
	}
}
